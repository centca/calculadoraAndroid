package com.example.myapplication2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class areaTriangulo extends AppCompatActivity {
    EditText aa,bb,cc,bbb,hh;
    TextView p,a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_triangulo);
        aa=(EditText)findViewById(R.id.b1);
        bb=(EditText)findViewById(R.id.b1);
        cc=(EditText)findViewById(R.id.c);
        bbb=(EditText)findViewById(R.id.b1);
        hh=(EditText)findViewById(R.id.b1);

        p=(TextView)findViewById(R.id.per);
        a=(TextView)findViewById(R.id.are);
    }

    public void goToUrlSaberMas(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://es.wikipedia.org/wiki/Tri%C3%A1ngulo"));
        startActivity(intent);
    }
    public void calcular(View view){

        if(!aa.getText().toString().isEmpty()) {
            float nro1 = Integer.parseInt(aa.getText().toString());
            float nro2 = Integer.parseInt(bb.getText().toString());
            float nro3 = Integer.parseInt(cc.getText().toString());
            float res = nro1 + nro2 + nro3;
            String resultado1 = String.valueOf(res);
            a.setText("Perímetro: " + resultado1);
        }
        if(!hh.getText().toString().isEmpty()){

            float nro1=Integer.parseInt(bbb.getText().toString());
            float nro2=Integer.parseInt(hh.getText().toString());
            float res= (nro1*nro2)/2;
            String resultado1=String.valueOf(res);
            p.setText("Área: "+resultado1);

        }
    }
}
