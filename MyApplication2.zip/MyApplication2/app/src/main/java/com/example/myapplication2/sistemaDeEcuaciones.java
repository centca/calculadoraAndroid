package com.example.myapplication2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.List;
import java.util.ArrayList;

public class sistemaDeEcuaciones extends AppCompatActivity {
    EditText x11,x22,y11,y22,res11,res22;
    TextView resX,resY;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.incognitas2);
        x11=(EditText)findViewById(R.id.x1);
        x22=(EditText)findViewById(R.id.x2);
        res11=(EditText)findViewById(R.id.res1);
        y11=(EditText)findViewById(R.id.y1);
        y22=(EditText)findViewById(R.id.y2);
        res22=(EditText)findViewById(R.id.res2);

        resX=(TextView)findViewById(R.id.resultadoX);
        resY=(TextView)findViewById(R.id.resultadoY);

    }



    public void goToUrlSaberMas(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://es.wikipedia.org/wiki/Sistema_de_ecuaciones_algebraicas"));
        startActivity(intent);
    }
    public void calcular(View view){
        String xx1,xx2,yy1,yy2,ress1,ress2;

        xx1=x11.getText().toString();
        float nrox1=Float.parseFloat(xx1);
        xx2=x22.getText().toString();
        float nrox2=Float.parseFloat(xx2);


        yy1=y11.getText().toString();
        float nroy1=Float.parseFloat(yy1);
        yy2=y22.getText().toString();
        float nroy2=Float.parseFloat(yy2);


        ress1=res11.getText().toString();
        float nrores1=Float.parseFloat(ress1);
        ress2=res22.getText().toString();
        float nrores2=Float.parseFloat(ress2);

        float x= (float) 0.0;
        float y= (float) 0.0;
        if(((nrox1 * nroy2) - (nroy1 * nrox2))!=0){
             x = ((nroy2 * nrores1) - (nroy1 * nrores2)) / ((nrox1 * nroy2) - (nroy1 * nrox2));
             y = ((nrox1 * nrores2) - (nrox2 * nrores1)) / ((nrox1 * nroy2) - (nroy1 * nrox2));
            String resultadoXX=String.valueOf(x);
            resX.setText(resultadoXX);

            String resultadoYY=String.valueOf(y);
            resY.setText(resultadoYY);

        }
/*
        resX.setText("No tiene solución o tiene infinitas soluciones");

        resY.setText("No tiene solución o tiene infinitas soluciones");
*/
        }
}
