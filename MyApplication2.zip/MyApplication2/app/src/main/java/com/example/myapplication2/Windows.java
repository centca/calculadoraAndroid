package com.example.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication2.comandosApple.comandosCopiaSeguridadApple;
import com.example.myapplication2.comandosApple.comandosFechaApple;
import com.example.myapplication2.comandosWindows.comandosCopiaSeguridadWindows;
import com.example.myapplication2.comandosWindows.comandosFechaWindows;
import com.example.myapplication2.comandosWindows.comandosFicheroWindows;
import com.example.myapplication2.comandosWindows.comandosInternetWindows;

public class Windows extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_windows);
    }
    public void internetWindows(View view){

        Intent intent = new Intent (view.getContext(), comandosInternetWindows.class);
        startActivityForResult(intent, 0);

    }
    public void ficherosWindows(View view){

        Intent intent = new Intent (view.getContext(), comandosFicheroWindows.class);
        startActivityForResult(intent, 0);

    }
    public void fechaWindows(View view){

        Intent intent = new Intent (view.getContext(), comandosFechaWindows.class);
        startActivityForResult(intent, 0);

    }
    public void copiaSeguridadWindows(View view){

        Intent intent = new Intent (view.getContext(), comandosCopiaSeguridadWindows.class);
        startActivityForResult(intent, 0);

    }
}
