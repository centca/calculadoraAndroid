package com.example.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication2.comandosApple.comandosFicherosApple;
import com.example.myapplication2.comandosLinux.comandosCopiaSeguridadLinux;
import com.example.myapplication2.comandosLinux.comandosFechaLinux;
import com.example.myapplication2.comandosLinux.comandosFicherosLinux;
import com.example.myapplication2.comandosLinux.comandosInternetLinux;

public class Linux extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linux);
    }
    public void internetLinux(View view){

        Intent intent = new Intent (view.getContext(), comandosInternetLinux.class);
        startActivityForResult(intent, 0);

    }
    public void ficherosLinux(View view){

        Intent intent = new Intent (view.getContext(), comandosFicherosLinux.class);
        startActivityForResult(intent, 0);

    }
    public void fechaLinux(View view){

        Intent intent = new Intent (view.getContext(), comandosFechaLinux.class);
        startActivityForResult(intent, 0);

    }
    public void copiaSeguridadLinux(View view){

        Intent intent = new Intent (view.getContext(), comandosCopiaSeguridadLinux.class);
        startActivityForResult(intent, 0);

    }
}
