package com.example.myapplication2;

public class Noticia {
    private int imagen;
    private String nombre;
    private String href;

    public Noticia(int imagen, String nombre, String href) {
        this.imagen = imagen;
        this.nombre = nombre;
        this.href = href;
    }

    public String getNombre() {
        return nombre;
    }

    public String getHref() {
        return href;
    }

    public int getImagen() {
        return imagen;
    }
}
