package com.example.myapplication2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class areaRectangulo extends AppCompatActivity {
    EditText aa,bb;
    TextView p,a,d;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_rectangulo);

        aa=(EditText)findViewById(R.id.b1);
        bb=(EditText)findViewById(R.id.h1);
        p=(TextView)findViewById(R.id.resP);
        a=(TextView)findViewById(R.id.resA);
        d=(TextView)findViewById(R.id.solD);

    }
    public void goToUrlSaberMas(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://es.wikipedia.org/wiki/Rect%C3%A1ngulo"));
        startActivity(intent);
    }
    public void calcular(View view){
        float nro1 = Integer.parseInt(aa.getText().toString());
        float nro2 = Integer.parseInt(bb.getText().toString());

        float solDiametro= (float) Math.sqrt((nro2*nro2)+(nro1*nro1));
        float solPer= (float) (2*((nro1+nro2)));
        float solAr= (float) (nro1*nro2);

        String resultado1 = String.valueOf(solDiametro);
        d.setText(resultado1);
        String resultado2 = String.valueOf(solAr);
        a.setText(resultado2);
        String resultado3 = String.valueOf(solPer);
        p.setText(resultado3);

    }
}

