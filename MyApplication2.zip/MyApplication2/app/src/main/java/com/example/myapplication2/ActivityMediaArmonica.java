package com.example.myapplication2;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ActivityMediaArmonica extends AppCompatActivity {
    EditText a;
    TextView s;
    String valor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mediaarmonica);
        a=(EditText)findViewById(R.id.editText);
        s=(TextView)findViewById(R.id.resultado);
    }
    public void goToUrlSaberMas(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://es.wikipedia.org/wiki/Media_arm%C3%B3nica"));
        startActivity(intent);
    }
    public void calcularEcuacion(View view){
        String valor = a.getText().toString();
        String[] datos = valor.split(" ");
        List<Float> numeros=new ArrayList<Float>();
        int i;
        for (i=0;i<datos.length;i++){
            float nro1=Float.parseFloat(datos[i]);
            numeros.add((float) (1.0/nro1));
        }
        float res= (float) 0.0;
        for(i=0;i<numeros.size();i++){
            res+=numeros.get(i);
        }
        res=1/res;
        String resultado=String.valueOf(res);
        s.setText("Solución: "+resultado);


    }
}
