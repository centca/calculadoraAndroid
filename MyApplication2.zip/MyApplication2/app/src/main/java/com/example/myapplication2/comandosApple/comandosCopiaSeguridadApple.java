package com.example.myapplication2.comandosApple;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.myapplication2.R;

public class comandosCopiaSeguridadApple extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comandos_copia_seguridad_apple);
    }
}
