package com.example.myapplication2;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//import android.support.v7.app.ActionBarActivity;

public class MainActivity extends AppCompatActivity {
    /*
    Declarar instancias globales
     */
    private RecyclerView recycler;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager lManager;

    List<Noticia> items = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        items.add(new Noticia(R.drawable.descarga, "Angel Beats", "https"));
        items.add(new Noticia(R.drawable.images_dino_augdg, "Death Note", "456"));
        new Content().execute();

        // Obtener el Recycler
        recycler = (RecyclerView) findViewById(R.id.reciclador);
        recycler.setHasFixedSize(true);

        // Usar un administrador para LinearLayout
        lManager = new LinearLayoutManager(this);
        recycler.setLayoutManager(lManager);

        // Crear un nuevo adaptador
        adapter = new NoticiaAdapter(items);
        recycler.setAdapter(adapter);
    }

    private class Content extends AsyncTask<Void, Void, Void> {
        String urlPublico = "https://www.publico.es/ciencias";
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                //Connect to the website
                Document doc = Jsoup.connect(urlPublico).get();
                Elements articulos = doc.select("div.listing-item");
                for (Element elem : articulos) {

                    String titular = elem.getElementsByClass("page-link").text();
                    String enlace = "https://www.publico.es" + (elem.getElementsByAttribute("href").attr("href"));

                    items.add(new Noticia(R.drawable.descarga, titular, enlace));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
