package com.example.myapplication2.comandosWindows;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.myapplication2.R;

public class comandosFicheroWindows extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comandos_fichero_windows);
    }
}
