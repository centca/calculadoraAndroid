package com.example.myapplication2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class pantallaPrincipalComandos extends AppCompatActivity {
    private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_principal_comandos);
    }
    public void irAApple(View view){

        Intent intent = new Intent (view.getContext(), Apple.class);
        startActivityForResult(intent, 0);

    }

    public void irAWindows(View view){

        Intent intent = new Intent (view.getContext(), Windows.class);
        startActivityForResult(intent, 0);

    }

    public void irALinux(View view){

        Intent intent = new Intent (view.getContext(), Linux.class);
        startActivityForResult(intent, 0);

    }
}
