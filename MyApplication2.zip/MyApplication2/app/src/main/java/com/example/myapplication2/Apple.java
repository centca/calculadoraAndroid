package com.example.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication2.comandosApple.comandosCopiaSeguridadApple;
import com.example.myapplication2.comandosApple.comandosFechaApple;
import com.example.myapplication2.comandosApple.comandosFicherosApple;
import com.example.myapplication2.comandosApple.comandosInternetApple;

public class Apple extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apple);
    }
    public void internetApple(View view){

        //Intent intent = new Intent (view.getContext(), comandosInternetApple.class);
        Intent intent = new Intent (view.getContext(), noticiasDeportes.class);
        startActivityForResult(intent, 0);

    }
    public void ficherosApple(View view){

        Intent intent = new Intent (view.getContext(), comandosFicherosApple.class);
        startActivityForResult(intent, 0);

    }
    public void fechaApple(View view){

        Intent intent = new Intent (view.getContext(), comandosFechaApple.class);
        startActivityForResult(intent, 0);

    }
    public void copiaSeguridadApple(View view){

        Intent intent = new Intent (view.getContext(), comandosCopiaSeguridadApple.class);
        startActivityForResult(intent, 0);

    }
}
