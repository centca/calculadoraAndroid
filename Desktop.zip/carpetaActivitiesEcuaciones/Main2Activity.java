package com.example.myapplication2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    EditText a,b,c;
    TextView s,t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ecuacion2grado);

        a=(EditText)findViewById(R.id.ParametroA);
        b=(EditText)findViewById(R.id.ParametroB);
        c=(EditText)findViewById(R.id.ParametroC);
        s=(TextView)findViewById(R.id.textView2);
        t=(TextView)findViewById(R.id.textView3);
    }
    public void goToUrlSaberMas(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://es.wikipedia.org/wiki/Ecuaci%C3%B3n_de_segundo_grado"));
        startActivity(intent);
    }
    public void calcularEcuacion(View view){
        String valor1,valor2,valor3;
        if(a.getText().toString().isEmpty()){
            valor1="0";
        }else{
            valor1=a.getText().toString();
        }

        if(b.getText().toString().isEmpty()){
            valor2="0";
        }else{
            valor2=b.getText().toString();
        }

        if(c.getText().toString().isEmpty()){
            valor3="0";
        }else{
            valor3=c.getText().toString();
        }


        float nro1=Integer.parseInt(valor1);
        float nro2=Integer.parseInt(valor2);
        float nro3=Integer.parseInt(valor3);


        float solucion1= (float)(
                         ((-nro2)-Math.sqrt((nro2*nro2)-(4*nro1*nro3)))
                        /(2*nro1)
        );
        float solucion2= (float)(
                          ((-nro2)+Math.sqrt((nro2*nro2)-(4*nro1*nro3)))
                                  /(2*nro1)
                                );
/*
        float sol1 = (float)Math.sqrt(nro1);
        float sol2 = (float)Math.sqrt(nro2);
        float sol3 = (float)Math.sqrt(nro3);
*/
  //      String resultado1=String.valueOf(sol1);

        String resultado1=String.valueOf(solucion1);
        String resultado2=String.valueOf(solucion2);
        if(resultado1.equals("NaN")) {
            resultado1="Existe una raíz negativa";
        }
        if(resultado2.equals("NaN")) {
            resultado2="Existe una raíz negativa";
        }
        s.setText("Solución 1: "+resultado1);
        t.setText("Solución 2: "+resultado2);
    }
}
